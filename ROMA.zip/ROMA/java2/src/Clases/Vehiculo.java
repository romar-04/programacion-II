/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clases;

/**
 *
 * @author Danilo de los Rios
 */
public class Vehiculo {
    //Atributos
    protected String fecha_fabricacion;
    protected String VIN_chasis;
    protected String VIN_motor;

    public Vehiculo(String fecha_fabricacion, String VIN_chasis, String VIN_motor) {
        this.fecha_fabricacion = fecha_fabricacion;
        this.VIN_chasis = VIN_chasis;
        this.VIN_motor = VIN_motor;
    }

    public String getFecha_fabricacion() {
        return fecha_fabricacion;
    }

    public String getVIN_chasis() {
        return VIN_chasis;
    }

    public String getVIN_motor() {
        return VIN_motor;
    }
    
    
     }

