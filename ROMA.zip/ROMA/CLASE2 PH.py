# Clase padre Vehículo
class Vehiculo:
    def __init__(self, fecha_fabricacion, vin_chasis, vin_motor):
        self.fecha_fabricacion = fecha_fabricacion
        self.vin_chasis = vin_chasis
        self.vin_motor = vin_motor

    def obtener_fecha_fabricacion(self):
        return self.fecha_fabricacion

    def obtener_vin_chasis(self):
        return self.vin_chasis

    def obtener_vin_motor(self):
        return self.vin_motor

class Automovil(Vehiculo):
    def __init__(self, fecha_fabricacion, vin_chasis, vin_motor, marca, modelo, precio):
        super().__init__(fecha_fabricacion, vin_chasis, vin_motor)
        self.marca = marca
        self.modelo = modelo
        self.precio = precio

    def obtener_marca(self):
        return self.marca

    def obtener_modelo(self):
        return self.modelo

    def obtener_precio(self):
        return self.precio

    def mostrar_datos(self):
        return (f"Automóvil {self.marca} {self.modelo}:\n"
                f"Fecha de fabricación: {self.fecha_fabricacion}\n"
                f"VIN Chasis: {self.vin_chasis}\n"
                f"VIN Motor: {self.vin_motor}\n"
                f"Precio: ${self.precio}")

# Instanciando la clase Automóvil y mostrando sus atributos
auto = Automovil("2023-01-15", "1HGCM82633A123456", "A123456B7890", "Toyota", "Corolla", 20000)
print(auto.mostrar_datos())
