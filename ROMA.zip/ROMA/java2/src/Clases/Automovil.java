/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clases;

/**
 *
 * @author Danilo de los Rios
 */
public class Automovil extends Vehiculo {
    protected String marca, modelo, precio;
    
    public Automovil(String fecha_fabricacion, String VIN_chasis,String VIN_motor, String marca, String modelo, String precio){
      super(fecha_fabricacion,VIN_chasis,VIN_motor);
      this.marca=marca;
      this.modelo=modelo;
      this.precio=precio;
    }

    public String getMarca() {
        return marca;
    }

    public String getModelo() {
        return modelo;
    }

    public String getPrecio() {
        return precio;
    }
    
    public void mostrardatos(){
    System.out.println("Datos del automovil:");
    System.out.println("Fecha de fabricacion:"+getFecha_fabricacion());
    System.out.println("Chasis:"+getVIN_chasis());
    System.out.println("Motor:"+getVIN_motor());
    System.out.println("Marca:"+marca);
    System.out.println("Modelo:"+modelo);
    System.out.println("Precio:"+precio);
}
}
