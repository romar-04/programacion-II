/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clases;

/**
 *
 * @author Danilo de los Rios
 */
public class Main {
     public static void main(String[] args) {
        Automovil miAutomovil = new Automovil(
            "2023-10-01", 
            "CETI", 
            "1473231",
            "KIA", 
            "PICANTO", 
            "15000.00" 
        );
        miAutomovil.mostrardatos();
    }
    
}
