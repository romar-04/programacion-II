from datetime import datetime

class Clientes:
    def __init__(self, cedula, nombre, apellido, telefono, correo, direccion, fecha_nacimiento):
        self.cedula = cedula
        self.nombre = nombre
        self.apellido = apellido
        self.telefono = telefono
        self.correo = correo
        self.direccion = direccion
        self.fecha_nacimiento = fecha_nacimiento


    def obtener_atributos(self):
        return {
            "Cédula": self.cedula,
            "Nombre": self.nombre,
            "Apellido": self.apellido,
            "Teléfono": self.telefono,
            "Correo": self.correo,
            "Dirección": self.direccion,
            "Fecha de Nacimiento": self.fecha_nacimiento
        }
    
    def obtener_datos(self):
        return (f"Cédula: {self.cedula}, Nombre: {self.nombre}, Apellido: {self.apellido}, "
                f"Teléfono: {self.telefono}, Correo: {self.correo}, Dirección: {self.direccion}, "
                f"Fecha de nacimiento: {self.fecha_nacimiento}")

    def calcular_edad(self):
        
        año_nacimiento = int(self.fecha_nacimiento[:4])
        
        año_actual = datetime.now().year
        
        return año_actual - año_nacimiento

    def obtener_mensaje(self):
        edad = self.calcular_edad()
        return f"Mi nombre es {self.nombre} {self.apellido} y vivo en {self.direccion} y tengo {edad} años de edad."

cliente = Clientes(
    cedula="4567823986",
    nombre="Romario",
    apellido="Sanchez",
    telefono="7689542376",
    correo="romario@example.com",
    direccion="Calle 675",
    fecha_nacimiento="1990/02/9"
)

print(f"Mi nombre es {cliente.nombre} {cliente.apellido} y vivo en {cliente.direccion} y tengo {cliente.calcular_edad()} años de edad")