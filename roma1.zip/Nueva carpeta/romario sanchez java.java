public class Main {
    class Clientes {
        private String cedula;
        private String nombre;
        private String apellido;
        private String telefono;
        private String correo;
        private String direccion;
        private String fecha_nacimiento;
    
        public Clientes(String cedula,String nombre, String apellido, String telefono, String correo, String direccion, String fecha_nacimiento){
            this.cedula = cedula;
            this.nombre = nombre;
            this.apellido = apellido;
            this.telefono = telefono;
            this.correo = correo;
            this.direccion = direccion;
            this.fecha_nacimiento = fecha_nacimiento;
        }
        
        
        public void datos(){
            System.out.println(this.nombre + this.apellido + ":" + "");
            System.out.println("-Cedula: " + this.cedula);
            System.out.println("-Correo: " + this.correo);
            System.out.println("-Telefono: "+ this.telefono);
            System.out.println("-Direccion: " + this.direccion);
        }
        
        public int calcularEdad(){
               int añoNacimiento = Integer.parseInt(fecha_nacimiento.substring(0,4));
               int añoActual = LocalDate.now().getYear();
               return añoActual - añoNacimiento;
        
        }
        public void mensaje(){
            int edad = calcularEdad();
            System.out.println("Mi nombre es: " + nombre + " " + apellido +  
            "\nmi direccion es: " + direccion + " \nmi edad es: " + edad + " años");
    }
        public static void main(String[] args) {
            Clientes Luna = new Clientes ("1048437592", "romario", "SANCHEZ ", "3002934363", "ahumedo2005@gmail.com", "calle 675", "1990/02/19");
            romario.mensaje();
      }
    }
}
